import React, { useEffect, useState } from "react";

function App() {
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [status, setStatus] = useState("Pending");
  const [filterSubject, setFilterSubject] = useState("All");
  const [assignments, setAssignments] = useState(() => {
    const saved = localStorage.getItem("assignmentTracker");
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 1,
            title: "Math Homework",
            subject: "Maths",
            dueDate: "2026-06-25",
            status: "Submitted",
          },
          {
            id: 2,
            title: "Physics Record",
            subject: "Physics",
            dueDate: "2026-06-27",
            status: "Pending",
          },
          {
            id: 3,
            title: "Chemistry Notes",
            subject: "Chemistry",
            dueDate: "2026-06-28",
            status: "Pending",
          },
        ];
  });

  useEffect(() => {
    localStorage.setItem("assignmentTracker", JSON.stringify(assignments));
  }, [assignments]);

  const formatDate = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const addAssignment = (e) => {
    e.preventDefault();

    if (!title.trim() || !subject.trim() || !dueDate) {
      alert("Please fill all fields");
      return;
    }

    const newAssignment = {
      id: Date.now(),
      title,
      subject,
      dueDate,
      status,
    };

    setAssignments([newAssignment, ...assignments]);
    setTitle("");
    setSubject("");
    setDueDate("");
    setStatus("Pending");
  };

  const deleteAssignment = (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this assignment?");
    if (confirmDelete) {
      setAssignments(assignments.filter((item) => item.id !== id));
    }
  };

  const updateStatus = (id, newStatus) => {
    setAssignments(
      assignments.map((item) =>
        item.id === id ? { ...item, status: newStatus } : item
      )
    );
  };

  const subjectList = ["All", ...new Set(assignments.map((item) => item.subject))];

  const filteredAssignments =
    filterSubject === "All"
      ? assignments
      : assignments.filter((item) => item.subject === filterSubject);

  const totalCount = assignments.length;
  const submittedCount = assignments.filter(
    (item) => item.status === "Submitted"
  ).length;
  const pendingCount = assignments.filter(
    (item) => item.status === "Pending"
  ).length;
  const lateCount = assignments.filter((item) => item.status === "Late").length;

  return (
    <div className="app">
      <div className="container">
        <h1 className="main-title">College Assignment Submission Tracker</h1>

        {/* Form Section */}
        <form className="assignment-form" onSubmit={addAssignment}>
          <input
            type="text"
            placeholder="Assignment Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <input
            type="text"
            placeholder="Subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />

          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />

          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="Pending">Pending</option>
            <option value="Submitted">Submitted</option>
            <option value="Late">Late</option>
          </select>

          <button type="submit">Add Assignment</button>
        </form>

        {/* Summary Cards */}
        <div className="summary-grid">
          <div className="summary-card">
            <h2>Total</h2>
            <p>{totalCount}</p>
          </div>
          <div className="summary-card">
            <h2>Submitted</h2>
            <p>{submittedCount}</p>
          </div>
          <div className="summary-card">
            <h2>Pending</h2>
            <p>{pendingCount}</p>
          </div>
          <div className="summary-card">
            <h2>Late</h2>
            <p>{lateCount}</p>
          </div>
        </div>

        {/* Filter */}
        <div className="filter-box">
          <select
            value={filterSubject}
            onChange={(e) => setFilterSubject(e.target.value)}
          >
            {subjectList.map((sub, index) => (
              <option key={index} value={sub}>
                {sub}
              </option>
            ))}
          </select>
        </div>

        {/* Table */}
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Title</th>
                <th>Subject</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Update</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {filteredAssignments.length > 0 ? (
                filteredAssignments.map((item) => (
                  <tr key={item.id}>
                    <td>{item.title}</td>
                    <td>{item.subject}</td>
                    <td>{formatDate(item.dueDate)}</td>
                    <td>
                      <span className={`status-badge ${item.status.toLowerCase()}`}>
                        {item.status}
                      </span>
                    </td>
                    <td>
                      <select
                        className="table-select"
                        value={item.status}
                        onChange={(e) => updateStatus(item.id, e.target.value)}
                      >
                        <option value="Pending">Pending</option>
                        <option value="Submitted">Submitted</option>
                        <option value="Late">Late</option>
                      </select>
                    </td>
                    <td>
                      <button
                        className="delete-btn"
                        onClick={() => deleteAssignment(item.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="no-data">
                    No assignments found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default App;